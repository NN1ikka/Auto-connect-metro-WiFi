package com.metrolink.autoconnect;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/**
 * Visible, user-initiated helper for the official MT_FREE captive portal.
 *
 * Only clicks two public navigation buttons if they are visible and enabled on
 * provider HTTPS pages. Does NOT bypass ads, timers, SMS/phone verification,
 * consent, payments or any authentication; never runs in the background.
 *
 * MT_FREE may reject third-party automated login. The user can disable the
 * helper or switch to Android's system captive-portal login at any time.
 */
public final class PortalActivity extends Activity {
    private static final int BG = Color.rgb(12, 19, 31);
    private static final int PANEL = Color.rgb(22, 32, 48);
    private static final int MINT = Color.rgb(78, 227, 193);
    private static final int WHITE = Color.rgb(239, 247, 250);
    private static final int SOFT = Color.rgb(158, 177, 194);

    private ConnectivityManager connectivity;
    private Network wifi;
    private boolean bound;
    private boolean autoEnabled = true;
    private boolean quickClicked;
    private boolean nextClicked;
    private boolean live;
    private WebView browser;
    private TextView state;
    private Button autoButton;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable checkButtons = new Runnable() {
        @Override public void run() {
            if (!live || browser == null) return;
            if (autoEnabled && isTrustedUrl(browser.getUrl())) {
                tryAutoClick();
            }
            handler.postDelayed(this, 1100L);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        connectivity = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        wifi = wifiNetwork();
        if (wifi != null) {
            // Android can otherwise route the embedded browser via mobile data
            // while MT_FREE remains a captive Wi-Fi network.
            try { bound = connectivity.bindProcessToNetwork(wifi); }
            catch (RuntimeException ignored) { bound = false; }
        }
        buildUi();
        handler.postDelayed(checkButtons, 1800L);
        live = true;
        if (wifi != null) {
            browser.loadUrl("https://auth.wi-fi.ru/");
        } else {
            state.setText(R.string.assist_no_wifi);
        }
    }

    private Network wifiNetwork() {
        try {
            for (Network network : connectivity.getAllNetworks()) {
                NetworkCapabilities caps = connectivity.getNetworkCapabilities(network);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) {
                    return network;
                }
            }
            for (Network network : connectivity.getAllNetworks()) {
                NetworkCapabilities caps = connectivity.getNetworkCapabilities(network);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return network;
            }
        } catch (RuntimeException ignored) { }
        return null;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            root.setPadding(0, top, 0, bottom);
            return insets;
        });
        setContentView(root);

        TextView title = new TextView(this);
        title.setText(R.string.assist_title);
        title.setTextColor(WHITE);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(18), dp(15), dp(18), dp(5));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        state = new TextView(this);
        state.setText(wifi == null ? R.string.assist_no_wifi : R.string.assist_loading);
        state.setTextColor(SOFT);
        state.setTextSize(12);
        state.setPadding(dp(18), 0, dp(18), dp(10));
        root.addView(state, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout controls = new LinearLayout(this);
        controls.setPadding(dp(8), dp(4), dp(8), dp(8));
        controls.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(controls, new LinearLayout.LayoutParams(-1, -2));

        autoButton = button(getString(R.string.assist_auto_on));
        controls.addView(autoButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        autoButton.setOnClickListener(v -> {
            autoEnabled = !autoEnabled;
            autoButton.setText(autoEnabled ? R.string.assist_auto_on : R.string.assist_auto_off);
            state.setText(autoEnabled ? R.string.assist_waiting : R.string.assist_paused);
        });
        Button reload = button(getString(R.string.assist_reload));
        controls.addView(reload, new LinearLayout.LayoutParams(0, dp(48), 1));
        reload.setOnClickListener(v -> {
            quickClicked = false;
            nextClicked = false;
            if (browser != null) browser.loadUrl("https://auth.wi-fi.ru/");
        });
        Button system = button(getString(R.string.assist_system));
        controls.addView(system, new LinearLayout.LayoutParams(0, dp(48), 1));
        system.setOnClickListener(v -> openSystemLogin());

        browser = new WebView(this);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser, false);
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                if (autoEnabled && newProgress >= 60 && isTrustedUrl(view.getUrl())) tryAutoClick();
            }
        });
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri link = request.getUrl();
                String scheme = link.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, link)); }
                catch (RuntimeException ignored) { }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                // Open the operator's official HTTPS authentication portal.
                // Do not render a connectivity-check endpoint as a WebView page.
                if (isTrustedUrl(url)) {
                    state.setText(R.string.assist_waiting);
                    if (autoEnabled) tryAutoClick();
                } else {
                    state.setText(R.string.assist_error);
                }
            }
            @Override public void onReceivedHttpError(WebView view, android.webkit.WebResourceRequest request,
                      android.webkit.WebResourceResponse response) {
                if (request.isForMainFrame() && response.getStatusCode() >= 400) {
                    state.setText(R.string.assist_error);
                }
            }
            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request,
                                                 android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) state.setText(R.string.assist_error);
            }
        });
        root.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView disclosure = new TextView(this);
        disclosure.setText(R.string.assist_disclaimer);
        disclosure.setTextColor(SOFT);
        disclosure.setTextSize(11);
        disclosure.setPadding(dp(15), dp(10), dp(15), dp(13));
        root.addView(disclosure, new LinearLayout.LayoutParams(-1, -2));
    }

    private boolean isTrustedUrl(String raw) {
        if (raw == null) return false;
        Uri uri = Uri.parse(raw);
        if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
        String h = uri.getHost();
        if (h == null) return false;
        h = h.toLowerCase(Locale.ROOT);
        return h.equals("auth.wi-fi.ru") || h.endsWith(".auth.wi-fi.ru")
            || h.equals("auth.maximatelecom.ru");
    }

    private void tryAutoClick() {
        if (!autoEnabled || browser == null || !isTrustedUrl(browser.getUrl())) return;
        // Page-local JavaScript: no JavaScript bridge, credential collection or
        // automated form submission. Only known, enabled, visible navigation
        // buttons. Check that no phone/OTP/password form is shown before Next.
        final String javascript = "(function(){var doneQuick=" + (quickClicked ? "true" : "false") +
            ";var doneNext=" + (nextClicked ? "true" : "false") + ";" +
            "if(document.visibilityState==='hidden')return 'NONE';" +
            "var targets=[].slice.call(document.querySelectorAll('button,a,input[type=button],input[type=submit],[role=button]'));" +
            "var fields=[].slice.call(document.querySelectorAll('input:not([type=hidden]):not([type=button]):not([type=submit]),textarea,select'));" +
            "var hasPrivateForm=fields.some(function(e){return e.getClientRects().length>0;});" +
            "var seen=window.__metroVisibleSince||(window.__metroVisibleSince={});" +
            "for(var i=0;i<targets.length;i++){var e=targets[i];" +
            "var txt=(e.value||e.innerText||e.textContent||'').trim().replace(/\\s+/g,' ').toLowerCase();" +
            "var label=txt==='quick connection to mt_free'?'QUICK':(txt==='next'?'NEXT':'');" +
            "if(!label || (label==='NEXT'&&(hasPrivateForm||!doneQuick||/подписк|оплат|стоимость|subscribe|purchase|payment|pay now|₽\\s*\\/|руб\\s*\\//i.test(document.body.innerText||''))) || (label==='NEXT'&&doneNext) || (label==='QUICK'&&doneQuick))continue;" +
            "if(e.disabled||e.getAttribute('aria-disabled')==='true')continue;" +
            "var s=getComputedStyle(e),r=e.getBoundingClientRect();" +
            "if(s.display==='none'||s.visibility!=='visible'||+s.opacity<0.1||r.width<30||r.height<10)continue;" +
            "var x=r.left+r.width/2,y=r.top+r.height/2;" +
            "if(x<0||y<0||x>=innerWidth||y>=innerHeight)continue;" +
            "var top=document.elementFromPoint(x,y);if(top!==e&&!e.contains(top))continue;" +
            "if(!seen[label]){seen[label]=Date.now();return 'WAIT';}" +
            "if(Date.now()-seen[label]<4000)return 'WAIT';" +
            "if(window.__metroLastTap&&Date.now()-window.__metroLastTap<4500)return 'NONE';" +
            "window.__metroLastTap=Date.now();e.click();return label;" +
            "}return 'NONE';})()";
        // Never press a button twice in the same portal session. In particular,
        // do not click 'Next' again on later phone-number or consent forms.
        if (quickClicked && nextClicked) return;
        browser.evaluateJavascript(javascript, response -> {
            if (response == null || !autoEnabled) return;
            String result = response.replace("\"", "");
            if (result.equals("QUICK") && !quickClicked) {
                quickClicked = true;
                state.setText(R.string.assist_pressed_quick);
            } else if (result.equals("NEXT") && !nextClicked) {
                nextClicked = true;
                state.setText(R.string.assist_pressed_next);
            }
        });
    }

    private void openSystemLogin() {
        if (wifi == null) {
            try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); }
            catch (RuntimeException ignored) { }
            return;
        }
        try { startActivity(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)); }
        catch (RuntimeException ex) {
            try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); }
            catch (RuntimeException ignored) { }
        }
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextSize(11);
        b.setTextColor(MINT);
        b.setBackgroundColor(PANEL);
        return b;
    }

    private int dp(int value) {
        return (int) (getResources().getDisplayMetrics().density * value + .5f);
    }

    @Override protected void onDestroy() {
        live = false;
        handler.removeCallbacks(checkButtons);
        if (browser != null) {
            browser.stopLoading();
            browser.destroy();
            browser = null;
        }
        if (bound) {
            try { connectivity.bindProcessToNetwork(null); }
            catch (RuntimeException ignored) { }
        }
        super.onDestroy();
    }
}
