Metro AutoConnect v1.1 website.

The Android APK is built by GitHub Actions and placed into site/downloads/MetroAutoConnect.apk before deployment. The standalone site folder is a template: its Download APK link works only after the build has succeeded.

Follow ../README.md to publish the repository with GitHub Pages. The app does not skip the provider's authentication or advertising.
