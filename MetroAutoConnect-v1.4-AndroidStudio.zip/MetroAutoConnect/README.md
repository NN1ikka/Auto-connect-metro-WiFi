# Metro AutoConnect v1.4 (Android)

## Changes
- The optional embedded login page loads `https://auth.wi-fi.ru/` rather than the HTTP connectivity test URL, which showed `ERR_EMPTY_RESPONSE` on a tested phone.
- The normal Open Wi-Fi login button always leads to Android's Internet panel when Wi-Fi is connected instead of the `gowifi.ru` news homepage.
- Keeps the Android Wi-Fi suggestion for MT_FREE. User approval and the provider's authentication are still required.

## Limitations
- This does **not** bypass portal advertising, payments, verification or other operator restrictions.
- Android controls whether it connects automatically; the provider can require repeat sign-in.
- Embedded portal may be blocked by the operator. Prefer Android's **Sign in to MT_FREE** notification.
- Not tested on device; building APK requires Android SDK/Gradle or GitHub Actions.
