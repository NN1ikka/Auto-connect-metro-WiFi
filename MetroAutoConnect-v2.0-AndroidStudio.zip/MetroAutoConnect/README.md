# Metro AutoConnect v2.0 — Android 10–16

This version deliberately removes the embedded WebView captive-portal assistant which repeatedly failed to authenticate MT_FREE. The only reliable behavior a normal third-party Android app can provide without operator cooperation is registering an open MT_FREE network suggestion so Android can automatically reconnect.

## What it does

- Adds `MT_FREE` as an open Wi-Fi network suggestion via `WifiManager.addNetworkSuggestions`.
- Android manages automatic network selection and reconnection after the user's one-time approval.
- Restores the switch state from Android's actual suggestion list where supported (API 30+).
- Displays whether any Wi-Fi has validated internet or a captive portal; the app does **not** claim that a different Wi-Fi network is MT_FREE.
- Opens **Android's Internet panel** and Wi-Fi settings for official captive-portal sign-in.
- No embedded WebView, no password collection, no accessibility service, no SMS handling, no advertising skips, no background web requests.

## Important limitation

MT_FREE can require operator authorization and advertisements **after** the phone has joined the Wi-Fi network. The app cannot eliminate this requirement or guarantee zero-touch internet access. The provider's “Как дома” subscription is designed for authentication-free access; review its terms directly with the provider.

## First-use steps

1. Open the app and press **Enable auto-connect**. Grant Nearby Wi-Fi permission and approve the Android Wi-Fi suggestion prompt.
2. Enable Wi-Fi and ensure MT_FREE is allowed to auto-connect under Android Wi-Fi settings.
3. If Android shows **Sign in to network**, use that official Android flow.
4. If you already use MT_FREE as a saved network, Android may reconnect regardless of this app; it will still need authentication when the operator requires it.

## Building

Requires JDK 17, Android SDK platform 35/build-tools 35.0.0 and Gradle 8.9; run `gradle :app:assembleDebug`. This repository includes a CI workflow template. Debug APKs must not be treated as signed production releases.

**No Android SDK is installed in the ChatGPT artifact environment, so this source is not a compiled/tested APK.**
