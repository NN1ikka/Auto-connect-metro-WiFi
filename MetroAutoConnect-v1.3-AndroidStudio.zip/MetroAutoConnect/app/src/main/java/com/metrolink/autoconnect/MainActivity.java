package com.metrolink.autoconnect;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSuggestion;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowInsets;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;

/**
 * Metro AutoConnect: an Android-approved open Wi-Fi suggestion for MT_FREE.
 * No credentials, cookies, ad skipping, captive-portal interception or hidden HTTP requests.
 */
public final class MainActivity extends Activity {
    private static final String SSID = "MT_FREE";
    private static final String PREFS = "metro_prefs";
    private static final String KEY_ENABLED = "suggestion_enabled";
    private static final int REQUEST_WIFI_PERMISSION = 101;

    private static final int BG = Color.rgb(12, 19, 31);
    private static final int PANEL = Color.rgb(22, 32, 48);
    private static final int SOFT = Color.rgb(158, 177, 194);
    private static final int WHITE = Color.rgb(239, 247, 250);
    private static final int MINT = Color.rgb(78, 227, 193);
    private static final int AMBER = Color.rgb(255, 199, 101);

    private WifiManager wifiManager;
    private ConnectivityManager connectivity;
    private WifiNetworkSuggestion suggestion;
    private ConnectivityManager.NetworkCallback callback;

    private Button toggleButton;
    private TextView toggleState;
    private TextView networkStatus;
    private TextView networkDetail;
    private View statusDot;
    private boolean enabled;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);

        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        connectivity = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        suggestion = new WifiNetworkSuggestion.Builder().setSsid(SSID).build();
        enabled = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_ENABLED, false);

        buildInterface();
        refreshToggle();
        refreshNetwork();
        observeWifi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (networkStatus != null) refreshNetwork();
    }

    @Override
    protected void onDestroy() {
        if (callback != null) {
            try { connectivity.unregisterNetworkCallback(callback); }
            catch (RuntimeException ignored) { }
            callback = null;
        }
        super.onDestroy();
    }

    private void observeWifi() {
        callback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) { runOnUiThread(() -> refreshNetwork()); }
            @Override public void onLost(Network network) { runOnUiThread(() -> refreshNetwork()); }
            @Override public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                runOnUiThread(() -> refreshNetwork());
            }
        };
        try {
            NetworkRequest request = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build();
            connectivity.registerNetworkCallback(request, callback);
        } catch (RuntimeException ignored) {
            // The manual refresh and Wi-Fi settings shortcut remain available.
        }
    }

    private void onToggle() {
        if (enabled) {
            try {
                int result = wifiManager.removeNetworkSuggestions(Collections.singletonList(suggestion));
                if (result == WifiManager.STATUS_NETWORK_SUGGESTIONS_SUCCESS) {
                    enabled = false;
                    persistEnabled();
                    refreshToggle();
                    toast(getString(R.string.disabled_message));
                } else {
                    toast(getString(R.string.failed_with_code, result));
                }
            } catch (RuntimeException ex) {
                toast(getString(R.string.error_generic, safeMessage(ex)));
            }
            return;
        }
        final String neededPermission = Build.VERSION.SDK_INT >= 33
            ? Manifest.permission.NEARBY_WIFI_DEVICES
            : Manifest.permission.ACCESS_FINE_LOCATION;
        if (checkSelfPermission(neededPermission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { neededPermission }, REQUEST_WIFI_PERMISSION);
            return;
        }
        addSuggestion();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WIFI_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                addSuggestion();
            } else {
                toast(getString(Build.VERSION.SDK_INT >= 33
                    ? R.string.permission_needed : R.string.location_permission_needed));
            }
        }
    }

    private void addSuggestion() {
        if (!wifiManager.isWifiEnabled()) {
            toast(getString(R.string.state_detail_off));
        }
        try {
            int result = wifiManager.addNetworkSuggestions(Collections.singletonList(suggestion));
            if (result == WifiManager.STATUS_NETWORK_SUGGESTIONS_SUCCESS) {
                enabled = true;
                persistEnabled();
                refreshToggle();
                toast(getString(R.string.enabled_message));
            } else {
                toast(getString(R.string.failed_with_code, result));
            }
        } catch (RuntimeException ex) {
            toast(getString(R.string.error_generic, safeMessage(ex)));
        }
        refreshNetwork();
    }

    private void persistEnabled() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    private void refreshToggle() {
        toggleButton.setText(enabled ? R.string.disable_auto : R.string.enable_auto);
        toggleButton.setTextColor(enabled ? WHITE : BG);
        toggleButton.setBackground(background(enabled ? PANEL : MINT, 18));
        toggleState.setText(enabled ? R.string.auto_on : R.string.auto_off);
        toggleState.setTextColor(enabled ? MINT : SOFT);
    }

    private Network findWifiNetwork() {
        Network possible = null;
        try {
            for (Network network : connectivity.getAllNetworks()) {
                NetworkCapabilities caps = connectivity.getNetworkCapabilities(network);
                if (caps == null || !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue;
                if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) return network;
                if (possible == null) possible = network;
                if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) possible = network;
            }
        } catch (RuntimeException ignored) { }
        return possible;
    }

    private void refreshNetwork() {
        if (networkStatus == null) return;
        if (!wifiManager.isWifiEnabled()) {
            setNetworkState(R.string.state_wifi_off, R.string.state_detail_off, SOFT);
            return;
        }
        Network network = findWifiNetwork();
        if (network == null) {
            setNetworkState(R.string.state_no_wifi, R.string.state_detail_waiting, SOFT);
            return;
        }
        NetworkCapabilities caps = connectivity.getNetworkCapabilities(network);
        if (caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) {
            setNetworkState(R.string.state_portal, R.string.state_detail_portal, AMBER);
        } else if (caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
            setNetworkState(R.string.state_connected, R.string.state_detail_connected, MINT);
        } else {
            setNetworkState(R.string.state_checking, R.string.state_detail_checking, AMBER);
        }
    }

    private void setNetworkState(int titleRes, int descRes, int color) {
        networkStatus.setText(titleRes);
        networkDetail.setText(descRes);
        networkStatus.setTextColor(color);
        statusDot.setBackground(background(color, 100));
    }

    private void openLogin() {
        Network network = findWifiNetwork();
        if (network != null) {
            try {
                NetworkCapabilities caps = connectivity.getNetworkCapabilities(network);
                if (caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                    toast(getString(R.string.already_connected));
                    return;
                }
                if (caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) {
                    openIntent(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY));
                    return;
                }
            } catch (RuntimeException ignored) {
                // Fall through to the provider's official web link.
            }
        } else {
            toast(getString(R.string.need_wifi));
            openWifiSettings();
            return;
        }
        // Official MT_FREE URL. Authentication and ads remain controlled by the provider.
        openIntent(new Intent(Intent.ACTION_VIEW, Uri.parse("https://gowifi.ru")));
    }

    private void openWifiSettings() {
        openIntent(new Intent(Settings.ACTION_WIFI_SETTINGS));
    }

    private void openIntent(Intent intent) {
        try { startActivity(intent); }
        catch (RuntimeException ex) { toast(getString(R.string.no_handler)); }
    }

    private String safeMessage(Throwable ex) {
        String name = ex.getClass().getSimpleName();
        return name == null || name.isEmpty() ? "Android error" : name;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(30));
        // On Android 15/16, target API 35 content may draw edge-to-edge.
        // Respect system bar insets so buttons and text are never hidden.
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            int topInset;
            int bottomInset;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                topInset = bars.top;
                bottomInset = bars.bottom;
            } else {
                topInset = insets.getSystemWindowInsetTop();
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            root.setPadding(dp(24), dp(28) + topInset, dp(24), dp(30) + bottomInset);
            return insets;
        });
        scroll.addView(root);
        setContentView(scroll);

        // Brand and network.
        TextView icon = label("◉", 42, MINT, Typeface.BOLD);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(background(PANEL, 26));
        root.addView(icon, layout(dp(72), dp(72), 0));
        TextView brand = label(getString(R.string.title), 34, WHITE, Typeface.BOLD);
        root.addView(brand, layout(-1, -2, 22));
        TextView sub = label(getString(R.string.subtitle), 13, MINT, Typeface.BOLD);
        sub.setLetterSpacing(0.25f);
        root.addView(sub, layout(-1, -2, 2));
        TextView networkName = label(getString(R.string.network_name), 22, WHITE, Typeface.BOLD);
        root.addView(networkName, layout(-1, -2, 31));
        TextView networkCaption = label(getString(R.string.network_caption), 14, SOFT, Typeface.NORMAL);
        root.addView(networkCaption, layout(-1, -2, 2));

        LinearLayout statusPanel = panel();
        root.addView(statusPanel, layout(-1, -2, 24));
        TextView statusLabel = label(getString(R.string.state_label), 11, SOFT, Typeface.BOLD);
        statusLabel.setLetterSpacing(0.18f);
        statusPanel.addView(statusLabel);
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusPanel.addView(statusRow, layout(-1, -2, 15));
        statusDot = new View(this);
        statusRow.addView(statusDot, layout(dp(10), dp(10), 0));
        networkStatus = label("", 18, WHITE, Typeface.BOLD);
        LinearLayout.LayoutParams statusTextParams = layout(-1, -2, 0);
        statusTextParams.leftMargin = dp(12);
        statusRow.addView(networkStatus, statusTextParams);
        networkDetail = label("", 13, SOFT, Typeface.NORMAL);
        networkDetail.setLineSpacing(dp(3), 1.0f);
        statusPanel.addView(networkDetail, layout(-1, -2, 11));

        LinearLayout autoPanel = panel();
        root.addView(autoPanel, layout(-1, -2, 14));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        autoPanel.addView(row);
        TextView autoTitle = label(getString(R.string.automatic_title), 17, WHITE, Typeface.BOLD);
        row.addView(autoTitle, new LinearLayout.LayoutParams(0, -2, 1f));
        toggleState = label("", 12, MINT, Typeface.BOLD);
        row.addView(toggleState);
        TextView desc = label(getString(R.string.automatic_description), 13, SOFT, Typeface.NORMAL);
        desc.setLineSpacing(dp(3), 1f);
        autoPanel.addView(desc, layout(-1, -2, 10));
        toggleButton = actionButton("", true);
        autoPanel.addView(toggleButton, layout(-1, dp(54), 21));
        toggleButton.setOnClickListener(v -> onToggle());

        Button assisted = actionButton(getString(R.string.assist_open), true);
        root.addView(assisted, layout(-1, dp(58), 22));
        assisted.setOnClickListener(v -> {
            if (findWifiNetwork() == null) {
                toast(getString(R.string.need_wifi));
                openWifiSettings();
                return;
            }
            startActivity(new Intent(this, PortalActivity.class));
        });

        Button login = actionButton(getString(R.string.open_login), false);
        root.addView(login, layout(-1, dp(58), 22));
        login.setOnClickListener(v -> openLogin());
        Button settings = actionButton(getString(R.string.open_settings), false);
        root.addView(settings, layout(-1, dp(54), 10));
        settings.setOnClickListener(v -> openWifiSettings());

        LinearLayout helpPanel = panel();
        root.addView(helpPanel, layout(-1, -2, 22));
        helpPanel.addView(label(getString(R.string.hint_title), 16, WHITE, Typeface.BOLD));
        TextView steps = label(getString(R.string.hint_body), 13, SOFT, Typeface.NORMAL);
        steps.setLineSpacing(dp(5), 1f);
        helpPanel.addView(steps, layout(-1, -2, 12));
        TextView note = label(getString(R.string.note), 12, SOFT, Typeface.NORMAL);
        note.setLineSpacing(dp(4), 1f);
        root.addView(note, layout(-1, -2, 20));
    }

    private LinearLayout panel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(19), dp(20), dp(20));
        panel.setBackground(background(PANEL, 20));
        return panel;
    }

    private Button actionButton(String title, boolean accent) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(title);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(accent ? BG : WHITE);
        button.setBackground(background(accent ? MINT : PANEL, 18));
        button.setPadding(dp(12), 0, dp(12), 0);
        return button;
    }

    private TextView label(String text, int size, int color, int weight) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(color);
        tv.setTextSize(size);
        tv.setTypeface(Typeface.DEFAULT, weight);
        return tv;
    }

    private GradientDrawable background(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private LinearLayout.LayoutParams layout(int width, int height, int topDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
        params.topMargin = dp(topDp);
        return params;
    }

    private int dp(int value) {
        return (int) (getResources().getDisplayMetrics().density * value + 0.5f);
    }
}
