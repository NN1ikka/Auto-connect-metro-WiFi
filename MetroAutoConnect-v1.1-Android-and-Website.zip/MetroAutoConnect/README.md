# Metro AutoConnect v1.1 — MT_FREE (Android)

Android app to suggest MT_FREE for automatic Wi-Fi connection and launch the official captive-portal login. Version 1.1 adds an optional visible login assistant that can tap two known navigation buttons. Works in Russian and English (based on device language).

## What it does

- Suggests the **open** `MT_FREE` network to Android's `WifiNetworkSuggestion` system.
- Android decides whether and when to join. User approval may be requested.
- Detects when a Wi-Fi network needs captive-portal sign-in (without reading the SSID/location).
- Offers the system captive portal login; also provides an in-app official WebView portal, attempting to route it through the connected Wi-Fi network.
- Lets the user disable the network suggestion and open Wi-Fi settings.
- In the *foreground only*, the optional assistant may tap visible/enabled `Quick connection to MT_FREE` and `Next` buttons on HTTPS provider pages. One tap of each per session, with a short visibility delay; automatic taps can be paused.
- Does not request a phone number, save credentials, skip advertisements or timers, bypass authentication, or send data to a backend.
- No background service or aggressive polling; once approved, Android stores the Wi-Fi suggestion while the app remains installed.

## Important limitations

- **No unattended/silent login:** The MT_FREE operator requires its own sign-in. The assistant works only with its screen open; Android does not permit arbitrary background activity launches. MT_FREE can reject third-party automatic login or return error 129. The app does not bypass ads, timers, identity verification, payments or confirmation.
- **Experimental:** MT_FREE pages may change or reject in-app WebView sessions. Use **System login** or the ordinary browser fallback if automatic buttons do not work.
- An open Wi-Fi network may have a captive portal. Android's selection policy, device settings and operator changes can affect behavior.
- If the portal stays on 'Loading, please wait', the cause may be operator connectivity, browser/cookie/JavaScript behavior or the portal itself; the app cannot repair an operator server.
- Connection status represents the active **Wi-Fi transport**, not guaranteed to be specifically `MT_FREE`. The app avoids SSID/location inspection by design.
- Automatic Wi-Fi connection needs Wi-Fi turned on. If your phone jumps to mobile data, inspect ASUS network switch features and Android Wi-Fi preferences.
- The `enabled` switch represents the app's last successful Wi-Fi suggestion operation. Android's Wi-Fi control permission can later be revoked in system settings.

## Build an installable APK and publish its download site (GitHub Pages)

The repository includes a responsive Russian/English landing page in `site/index.html`. The GitHub Actions workflow `.github/workflows/build-apk.yml`:

1. Builds an **Android debug APK** in a GitHub-hosted runner with Android SDK 35 and Gradle 8.9.
2. Copies it to `site/downloads/MetroAutoConnect.apk` and creates a SHA-256 checksum.
3. Uploads the APK as an Actions artifact for manual download.
4. Deploys the download website to GitHub Pages with a working **Download APK / Скачать APK** link.

**Publishing instructions** (one-time):

1. Create a GitHub repository (for example `MetroAutoConnect`), with `main` as the default branch.
2. Upload/push the entire contents of this project to the repository, **including the hidden `.github` directory**. Do not upload only the ZIP file.
3. In the GitHub repository, choose **Settings > Pages > Build and deployment > Source: GitHub Actions**.
4. Under **Actions**, open **Build Android APK and website** and select **Run workflow** if it has not already run from the push.
5. When the build and deploy jobs succeed, the Actions run will show a published website. For a standard project repository named `MetroAutoConnect`, the URL is generally `https://YOUR-USERNAME.github.io/MetroAutoConnect/`.
6. Visit the website on Android and tap **Download APK / Скачать APK** to install the generated APK. Or download the `MetroAutoConnect-Android-APK` artifact from the Actions run (the artifact is itself a ZIP containing the APK).

If GitHub Pages is disabled or deployment is blocked, check the repository's Pages configuration and workflow permissions. No public hosting exists until you publish the repository and the workflow completes successfully.

**Security/availability:** This uses a debug-signed APK for testing and direct personal installation. Do not distribute it as a production app until you configure a private release signing key and verify its operation on real devices. The app has no built-in advertising/network tracking, but the provider's login page may contain its own ads and tracking.

## Build in Android Studio

1. Extract this project folder.
2. Install Android Studio, JDK 17 and Android SDK Platform 35, and select Gradle 8.9 for the project.
3. Open the project and allow Gradle sync to download Android Gradle Plugin 8.7.3.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install the generated `app/build/outputs/apk/debug/app-debug.apk` on your Android device.

## Run

1. Switch on Wi-Fi.
2. Press **Enable auto-connect** and grant Nearby Wi-Fi Devices permission (Android 13+) or location permission (Android 10–12).
3. Approve Android's Wi-Fi suggestion notification/dialog if requested.
4. If necessary, connect to MT_FREE manually in Android settings once.
5. When the system shows 'Sign in to MT_FREE', use **Assisted login (auto-tap buttons)** from the app to display the official portal. If that fails, use **Open Wi-Fi login** for the system captive-portal browser.
6. While the in-app portal is visible, the assistant tries to tap only `Quick connection to MT_FREE` and `Next` after the buttons become visible and enabled. If the provider requires phone/SMS verification, ads or other actions, complete them yourself.

## Compatibility

- Minimum: Android 10 (API 29)
- Target: Android 15 (API 35), usable on Android 16
- Build: Gradle 8.9 / AGP 8.7.3 / Java 17
- No external Android libraries or analytics.

## Resources

- Official Wi-Fi.ru instructions: https://faq.wi-fi.ru/faq/group/25
- Android Wi-Fi suggestion API: https://developer.android.com/develop/connectivity/wifi/wifi-suggest
- Android nearby Wi-Fi permission: https://developer.android.com/develop/connectivity/wifi/wifi-permissions

## v1.1 security design

- Automatic navigation is opt-in by opening the Assisted login screen; no Accessibility Service, overlay, background scraping, or hidden API usage.
- Automatic taps are restricted to HTTPS `gowifi.ru`, `wi-fi.ru`, its subdomains, and `maximatelecom.ru` sites. It does not intercept credentials or access other apps.
- Only the exact navigation buttons `Quick connection to MT_FREE` and `Next` are eligible, only when visible, on-screen, enabled and not covered. For `Next`, visible input forms prevent the tap. There is a short visibility wait. The code intentionally never clicks payment, consent, OTP or ad-skip buttons.
- The hosted download is a **debug-signed build for testing**; use a release key and run tests before redistribution.
- Provider restrictions: https://faq.wi-fi.ru/faq/group/25
